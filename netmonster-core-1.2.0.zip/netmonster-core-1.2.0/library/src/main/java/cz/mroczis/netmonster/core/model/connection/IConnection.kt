package cz.mroczis.netmonster.core.model.connection

/**
 * Marker interface for connection-related information
 */
interface IConnection